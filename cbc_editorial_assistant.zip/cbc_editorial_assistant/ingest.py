import json
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
import os

def load_articles():
    with open("data/news-dataset.json", "r", encoding="utf-8") as f:
        dataset = json.load(f)

    documents = []
    for item in dataset:
        article_id = item.get("content_id", "")
        headline = item.get("content_headline", "")
        categories = ", ".join([c["content_category"] for c in item.get("content_categories", [])])
        tags = ", ".join([t["name"] for t in item.get("content_tags", [])])
        department = item.get("content_department_path", "")
        word_count = item.get("content_word_count", "")

        content = (
            f"Headline: {headline}\n"
            f"Categories: {categories}\n"
            f"Tags: {tags}\n"
            f"Department: {department}\n"
            f"Word Count: {word_count}\n"
        )

        documents.append(Document(page_content=content, metadata={"id": article_id}))
    return documents

def create_vectorstore():
    docs = load_articles()
    splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100, length_function=len)
    chunks = splitter.split_documents(docs)

    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local("faiss_index")

if __name__ == "__main__":
    create_vectorstore()
