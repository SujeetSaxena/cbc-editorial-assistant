#from generator import generate_response

#def main():
 #   print("Welcome to CBC Editorial Assistant Chatbot!")
  #  while True:
   #     query = input("\nEnter your query (or 'exit'): ")
    #    if query.lower() == "exit":
     #       break
      #  response = generate_response(query)
       # print("\nResponse:")
        # print(response)

#if __name__ == "__main__":
#    main()


############
from generator import generate_response

def main():
    print("📰 CBC Editorial Assistant Chatbot (RAG)")
    print("Type your query or 'exit' to quit.")

    while True:
        query = input("\n🔍 Your query: ")
        if query.lower() == "exit":
            break
        response = generate_response(query)
        print("\n💬 Assistant:\n" + response)

if __name__ == "__main__":
    main()
