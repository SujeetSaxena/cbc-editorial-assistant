from retriever import get_relevant_docs
import requests

def generate_response(query: str, model: str = "Llama"):
    context_docs = get_relevant_docs(query)
    context = "\n\n".join([doc.page_content for doc in context_docs])

    prompt = f"""You are an editorial assistant for CBC.
Use the following context to respond to the user query.

Context:
{context}

Query: {query}

Answer:"""

    response = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": model, "prompt": prompt, "stream": False}
    )

    if response.status_code == 200:
        return response.json()["response"]
    else:
        return "⚠️ Error generating response."

