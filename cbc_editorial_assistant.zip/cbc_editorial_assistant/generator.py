from retriever import get_relevant_docs
import requests

#def generate_response(query: str, model: str = "llama2"):
def generate_response(query: str, model: str = "mistral"):
    context_docs = get_relevant_docs(query)
    context = "\n\n".join([doc.page_content for doc in context_docs])

    prompt = f"""You are an editorial assistant for CBC.
Use the following context to respond to the user query.

Context:
{context}

Query: {query}

Answer:"""

    try:
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False}
        )

        if response.status_code == 200:
            return response.json()["response"]
        else:
            print("⚠️ Error:", response.status_code, response.text)
            return "⚠️ Error generating response."

    except Exception as e:
        print("❌ Exception occurred:", str(e))
        return "❌ Failed to connect to local model. Is mistral running?"
