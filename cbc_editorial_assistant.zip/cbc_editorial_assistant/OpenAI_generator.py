import os
import openai
from retriever import get_relevant_docs
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("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")

def generate_response(query: str):
    context_docs = get_relevant_docs(query)
    context = "\n\n".join([doc.page_content for doc in context_docs])

    prompt = f"""You are a helpful assistant for CBC editorial team. Use the following context to answer the query.

Context:
{context}

Query: {query}
Answer:"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )

    return response['choices'][0]['message']['content']
