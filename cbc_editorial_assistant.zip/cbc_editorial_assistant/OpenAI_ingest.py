import json
from dotenv import load_dotenv
from langchain.text_splitter import CharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.docstore.document import Document
import os

load_dotenv()

def load_articles():
    with open("data/news-dataset.json", "r") as f:
        dataset = json.load(f)

    documents = []
    for item in dataset:
        article_id = item.get("content_id", "")
        headline = item.get("content_headline", "")
        content = f"Headline: {headline}\n\nCategories: {[c['content_category'] for c in item.get('content_categories', [])]}\n\nTags: {[t['name'] for t in item.get('content_tags', [])]}\n\nDepartment: {item.get('content_department_path')}\n\n"
        documents.append(Document(page_content=content, metadata={"id": article_id}))
    return documents

def create_vectorstore():
    docs = load_articles()
    splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100, length_function=len)
    chunks = splitter.split_documents(docs)

    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local("faiss_index")

if __name__ == "__main__":
    create_vectorstore()
